# RICE  > 2023-12-16 2:06pm
https://universe.roboflow.com/thanaree/rice-fgvkm

Provided by a Roboflow user
License: CC BY 4.0

