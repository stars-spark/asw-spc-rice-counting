# rice count > 2023-05-01 2:16am
https://universe.roboflow.com/asia-pacific-university-xxaah/rice-count

Provided by a Roboflow user
License: CC BY 4.0

