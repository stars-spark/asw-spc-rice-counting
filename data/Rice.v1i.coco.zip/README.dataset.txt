# rice > 2024-10-04 4:55am
https://universe.roboflow.com/annotation-gnc0j/rice-nqqbr

Provided by a Roboflow user
License: CC BY 4.0

