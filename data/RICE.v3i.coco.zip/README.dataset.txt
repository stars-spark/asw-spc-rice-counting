# RICE > 2024-02-17 9:42pm
https://universe.roboflow.com/ezekiel-se47x/rice-ljhi4

Provided by a Roboflow user
License: CC BY 4.0

